For mer informasjon om installering av bibliotek, se http://www.arduino.cc/en/Guide/Libraries
