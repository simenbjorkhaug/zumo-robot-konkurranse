package application;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
//import javafx.scene.control.Slider;
//import javafx.scene.control.ProgressBar;
//import javafx.beans.value.ChangeListener;
//import javafx.beans.value.ObservableValue;

public class MyController {
	private PLabSerial serialConnection = new PLabSerial();
	
	@FXML
    private Label redLedLabel;
	
//	@FXML
//    private Label greenLedLabel;
	
	@FXML
    private TextField serialPortNameField;
	
//	@FXML
//    private Slider mySlider;
//	
//	@FXML
//    private ProgressBar myProgressbar;
    
	@FXML
	void initialize() {
		String portName;
		if(serialConnection.openPLabPort()) {	
		    portName = serialConnection.getOpenPortName();}
		else {
			portName = "No PLab BT device found.";
		};
		serialPortNameField.setText(portName);
		serialConnection.addListener(this, "messageReceived");	
	}
	
	public void messageReceived(String message, int value) {
		if (message.equals("#redButtonPressed")) {
			arduinoRedButtonPressed(); return;
		}
	}
	
	void arduinoRedButtonPressed() {
		if(redLedLabel.getTextFill() == Color.RED) {
			redLedLabel.setTextFill(Color.BLACK);}
		else {
			redLedLabel.setTextFill(Color.RED);
		}
	}
	
	@FXML
	void redButtonPressed() {
	    serialConnection.sendMessage("#redButtonPressed",0);
	}
}
